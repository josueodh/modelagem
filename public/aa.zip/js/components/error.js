$(document).ready(function () {
    for (var prop in errors) {
        var $el = $('*[name="' + prop + '"]').first();

        $el.addClass('invalid');
        $el.after('<span class="text-danger" role="alert"><small>' + errors[prop][0] + '</small></span>');

        $el.on('change', function () {
            $el.removeClass('invalid');
            $el.next('span.text-danger').remove();
        });
    }
});