var valores = [];
var dias_projetos = document.querySelector('#dias_projeto');
var total_sem_desconto = document.querySelector('#total_sem_desconto');
var total_a_vista = document.querySelector('#total_vista');
var total_com_desconto = document.querySelector('#total_desconto');
var desconto_final = document.querySelector('#desconto_final');
function valueInput(elemento) {
    valores[elemento.valueOf()] = document.getElementById(elemento.valueOf()).value;
    calcularDias();
    calculaTotal();
}
function calcularDias() {
    if (valores['semanas_projeto']) {
        valores['dias'] = valores['semanas_projeto'] * 7;
        dias_projetos.value = valores['dias'];
    } else {
        valores['dias'] = 0;
        dias_projetos.value = valores['dias'];
    }
}
function calculaTotal() {
    if (validaValores()) {
        valores['subtotal'] = valores['valor_gerente'] * valores['horas_gerente'];
        valores['subtotal'] = valores['subtotal'] + valores['horas_projetista'] * valores['valor_projetista'] * valores['quantidade_projetista'];
        valores['subtotal'] = valores['subtotal'] * valores['semanas_projeto'];
        total_sem_desconto.value = valores['subtotal'].toFixed(2);
        calculaDescontoTotal();
    } else {
        total_sem_desconto.value = 0, 00;
        total_a_vista.value = 0, 00;
        total_a_vista.value = 0.00;
        total_desconto.value = 0.00;
    }
}
function calculaDesconto() {
    if (valores['desconto']) {
        return (valores['subtotal'] - desconto_final.value).toFixed(2);
    } else {
        return valores['subtotal'].toFixed(2);
    }
}

function descontoAVista(desconto) {
    if (valores['desconto_vista']) {
        return (desconto - (valores['desconto_vista'] * desconto / 100)).toFixed(2);
    } else {
        return desconto;
    }
}

function calculaDescontoTotal() {
    if(valores['desconto'] || valores['semanas-descontadas']){
        desconto_final.value  = (valores['subtotal'] * valores['desconto']/100 + valores['subtotal'] * valores['semanas_descontadas'] / valores['semanas_projeto']).toFixed(2);
        total_com_desconto.value = calculaDesconto();
        total_a_vista.value = descontoAVista(total_com_desconto.value);
        valores['total'] = total_com_desconto.value;
    }else{
        desconto_final.value = 0.00;
        total_com_desconto.value = valores['subtotal'].toFixed(2);
        total_a_vista.value = valores['subtotal'].toFixed(2);
    }

}

function validaValores(){
    return valores['valor_gerente'] && valores['valor_projetista'] && valores['horas_projetista'] && valores['horas_gerente'] && valores['quantidade_projetista'] && valores['semanas_projeto'];
}