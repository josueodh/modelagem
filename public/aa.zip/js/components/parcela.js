
    document.forms.payment.addEventListener("submit", payment);
    function payment(e) {
        e.preventDefault();
        var tbody = document.querySelector('#gerar-parcelas');
        if(tbody.childNodes.length > 6 ){
            for(var j = 0 ; j < 6 ; j++){
                tbody.removeChild(document.querySelector('.precificacao'));
            }
        }
        for (var i = 1; i <= 6; i++) {
            document.querySelector('.card-parcelas').style.display = "unset";
            var tdNumero = document.createElement('td');
            var tdParcelaDesconto = document.createElement('td');
            var tdParcelaSemDesconto = document.createElement('td');
            tdParcelaSemDesconto.textContent = 'R$' + (total_sem_desconto.value / i).toFixed(2);
            tdParcelaDesconto.textContent = 'R$' + (total_com_desconto.value / i).toFixed(2);
            tdNumero.textContent = i;
            var tr = document.createElement('tr');
            tr.classList.add('precificacao');
            tr.appendChild(tdNumero);
            tr.appendChild(tdParcelaSemDesconto);
            tr.appendChild(tdParcelaDesconto);
            tbody.appendChild(tr);
        }

    }