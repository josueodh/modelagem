<?php if(session('success')): ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function(){
                Swal.fire(
                    'Operação concluida com sucesso!',
                    null,
                    'success'
                )
            });
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?><?php /**PATH /home/josueodh/Área de Trabalho/modelagem/resources/views/includes/success.blade.php ENDPATH**/ ?>