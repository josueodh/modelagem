<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-book"></i> Telefone</b>
    <br>
    <?php echo e($client->cellphone); ?>

</li>
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-book"></i> E-mail</b>
    <br>
    <?php echo e($client->email); ?>

</li>
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-book"></i> Status</b>
    <br>
    <?php echo e($client->status); ?>

</li>
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-book"></i> Descrição</b>
    <br>
    <?php echo e($client->description); ?>

</li><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/clients/list.blade.php ENDPATH**/ ?>