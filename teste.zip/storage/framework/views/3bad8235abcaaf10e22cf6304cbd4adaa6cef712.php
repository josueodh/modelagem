<div class="col-md-10 offset-md-1 col-12">
    <div class="card card-outline card-code">
        <div class="card-header">
            <h3 class="card-title title-show"><?php echo e($title ?? null); ?> </h3>
        </div>
        <div class="card-body">
            <ul class="list-group list-group-flush">
                <?php echo e($list ?? null); ?>

            </ul>
        </div>
        <div class="card-footer">
            <form class="form-delete" action="<?php echo e($delete ?? '/'); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button type="submit" class="btn btn-danger float-right "><i class="fas fa-trash"></i> Deletar</button>
            </form>
            <a href="<?php echo e($edit ?? '/'); ?>">
                <button type="submit"  class="btn btn-primary float-right btn-delete"><i class="fas fa-pen"></i> Editar</button>
            </a>
        </div>
    </div>
</div><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/components/show.blade.php ENDPATH**/ ?>