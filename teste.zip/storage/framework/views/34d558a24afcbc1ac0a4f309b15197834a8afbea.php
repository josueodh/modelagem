<div class="card-body">
    <div class="form-group">
        <label for="nome">Nome</label>
        <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $member->name)); ?>"  id="nome">
    </div>
    <div class="form-group">
        <label for="email">E-mail</label>
        <input type="email" class="form-control" name="email" value="<?php echo e(old('email', $member->email)); ?>" id="email">
    </div>
    <div class="form-group">
        <label for="cargo">Cargo</label>
        <select class="form-control" id="cargo">
            <option></option>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($role->id); ?>" ><?php echo e($role->name); ?></option>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
</div><?php /**PATH /home/josueodh/Área de Trabalho/modelagem/resources/views/members/form.blade.php ENDPATH**/ ?>