<div class="row">
    <div class="form-group col-sm-6">
        <label class="required" for="nome">Nome</label>
        <input type="text" class="form-control" required value="<?php echo e(old('name', $project->name)); ?>" name="name" id="nome">
    </div>
    <div class="form-group col-sm-6">
        <label class="required" for="price">Preço</label>
        <input type="number" step="0.01" class="form-control" required value="<?php echo e(old('price', $project->price)); ?>" name="price" id="price">
    </div>
    <div class="form-group col-sm-6">
        <label class="required">Categoria de Projetos</label>
        <select class="form-control select2" name="category_id" value="<?php echo e(old('category_id', $project->category_id)); ?>" required>
            <option ></option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-md-6 col-12">
        <div class="form-group">
            <label class="required">Membros</label>
            <select class="select2" multiple="multiple" name="user[]" value="<?php echo e(json_encode(old('users', $project->user->pluck('id')))); ?>" required style="width: 100%;">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="form-group col-sm-6">
        <label class="required" for="price">Cliente</label>
        <input type="text" class="form-control" required value="<?php echo e(old('client', $project->client)); ?>" name="client" id="client">
    </div>
    <div class="form-group col-sm-12">
        <label class="required">Descrição do Projeto</label>
        <textarea name="description" class="form-control" required id="description" rows="5"><?php echo e(old('description',$project->description)); ?></textarea>        
    </div>
</div><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/projects/form.blade.php ENDPATH**/ ?>