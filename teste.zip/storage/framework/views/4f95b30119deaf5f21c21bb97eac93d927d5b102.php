<div class="row">
    <div class="col-sm-12">
        <div class="form-group">
            <label class="required">Nome</label>
            <input type="text" name="name" class="form-control" required autofocus value="<?php echo e(old('name', $role->name)); ?>">
        </div>
    </div>
</div>
<?php /**PATH /home/josueodh/Área de Trabalho/modelagem/resources/views/roles/form.blade.php ENDPATH**/ ?>