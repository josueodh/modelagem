<?php $__env->startSection('content'); ?>


<?php $__env->startComponent('components.table'); ?>
    <?php $__env->slot('create', route('categorys.create')); ?>
    <?php $__env->slot('titulo', 'Categoria'); ?>


    <?php $__env->slot('head'); ?>
        <th>Nome</th>
        <th></th>
    <?php $__env->endSlot(); ?>
    <?php $__env->slot('body'); ?>
        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($category->name); ?></td>
                <td class="options">
                    <a href="<?php echo e(route('categorys.show', $category->id)); ?>" class="btn btn-secondary"><i class="fas fa-eye"></i></a>
                    <a href="<?php echo e(route('categorys.edit', $category->id)); ?>" class="btn btn-primary"><i class="fas fa-pen"></i></a>
                    <form class="form-delete" action="<?php echo e(route('categorys.destroy', $category->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/components/dataTable.js')); ?>"></script>
    <script src="<?php echo e(asset('js/components/sweetAlert.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/category/index.blade.php ENDPATH**/ ?>