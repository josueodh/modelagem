<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>

<body class="hold-transition login-page">
    <div id="app" class="login-box">
        <div class="login-logo">
            <a><b><?php echo e(config('app.name', 'Blog Edur')); ?></b></a>
        </div>

        <div class="card">
            <div class="card-body login-card-body">
                <p class="login-box-msg">Faça o login para iniciar sua sessão</p>

                <form action="<?php echo e(route('login')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <input placeholder="E-mail" type="email" class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" name="email" autocomplete="username"
                            value="<?php echo e(old('email')); ?>" required autofocus>
                        <div class="input-group-append">
                            <span class="input-group-text">
                                <i class="fas fa-envelope"></i>
                            </span>
                        </div>
                        <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="input-group mb-3">
                        <input placeholder="Senha" type="password" class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>"
                            name="password" autocomplete="current-password" required>
                        <div class="input-group-append">
                            <span class="input-group-text">
                                <i class="fas fa-lock"></i>
                            </span>
                        </div>
                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="row">
                        <div class="col-8">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                    <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                <label class="form-check-label" for="remember">
                                    Lembre-me
                                </label>
                            </div>
                        </div>
                        <div class="col-4">
                            <button type="submit" class="btn btn-code btn-block">Login</button>
                        </div>
                    </div>
                </form>

                <hr>

                <p class="mb-1">
                    <?php if(Route::has('password.request')): ?>
                    <a href="<?php echo e(route('password.request')); ?>">
                        Esqueceu sua senha?
                    </a>
                    <?php endif; ?>
                </p>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/auth/login.blade.php ENDPATH**/ ?>