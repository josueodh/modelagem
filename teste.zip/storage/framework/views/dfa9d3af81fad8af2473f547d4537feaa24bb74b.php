<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.create'); ?>
    <?php $__env->slot('title', 'Criar Usuário'); ?>
    <?php $__env->slot('url', route('users.store')); ?>
    <?php $__env->slot('form'); ?>
        <?php echo $__env->make('users.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/user/create.blade.php ENDPATH**/ ?>