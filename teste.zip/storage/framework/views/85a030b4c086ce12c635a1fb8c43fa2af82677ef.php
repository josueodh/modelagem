<div class="row">
    <div class="form-group col-sm-6">
        <label class="required" for="nome">Nome</label>
        <input type="text" class="form-control" required value="<?php echo e(old('name', $role->name)); ?>" name="name" id="nome">
    </div>
    <div class="form-group col-sm-6">
        <label class="required">Departamento</label>
        <select class="form-control select2" name="departament_id" value="<?php echo e(old('departament_id', $role->departament_id)); ?>" required>
            <option></option>
            <?php $__currentLoopData = $departaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($departament->id); ?>"><?php echo e($departament->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group col-sm-12">
        <label class="required">Descrição do Cargo</label>
        <textarea name="description" class="form-control" required id="description" rows="5"><?php echo e(old('description',$role->description)); ?></textarea>        
    </div>
</div><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/roles/form.blade.php ENDPATH**/ ?>