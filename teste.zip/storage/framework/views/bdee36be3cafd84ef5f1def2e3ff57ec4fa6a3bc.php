<div class="row">
    <div class="form-group col-sm-12">
        <label class="required" >Nome</label>
        <input type="text" class="form-control" required value="<?php echo e(old('name', $category->name)); ?>" name="name">
    </div>
</div><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/categories/form.blade.php ENDPATH**/ ?>