<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.show'); ?>
    <?php $__env->slot('title', $role->name); ?>
    <?php $__env->slot('list'); ?>
        <?php echo $__env->make('roles.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->endSlot(); ?>
    <?php $__env->slot('delete',route('roles.destroy',$role->id)); ?>    
    <?php $__env->slot('edit',route('roles.edit',$role->id)); ?>    
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/components/sweetAlert.js')); ?>"></script>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/roles/show.blade.php ENDPATH**/ ?>