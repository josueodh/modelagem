
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-book"></i> Mensagem</b>
    <br>
    <?php echo e($warning->description); ?>

</li>
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-user"></i> Autor: </b>
    <?php echo e($warning->user['name']); ?>

</li>
<?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/warnings/list.blade.php ENDPATH**/ ?>