<div class="col-md-10 offset-md-1 col-12">
    <div class="card card-outline card-code">
        <div class="card-header">
            <h3 class="card-title title-form"><?php echo e($title ?? null); ?> </h3>
        </div>
        <div class="card-body">
            <form id="form-adicionar" action="<?php echo e($url ?? '/'); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo e($form ?? null); ?>

            </form>
        </div>
        <div class="card-footer">
            <button type="submit" form="form-adicionar" class="btn btn-code float-right">Cadastrar</button>
            <?php echo e($voltar ?? null); ?>

        </div>
    </div>
</div><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/components/create.blade.php ENDPATH**/ ?>