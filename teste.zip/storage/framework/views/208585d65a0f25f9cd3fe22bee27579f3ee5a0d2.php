
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-book"></i> Descrição</b>
    <br>
    <?php echo e($departament->description); ?>

</li><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/departaments/list.blade.php ENDPATH**/ ?>