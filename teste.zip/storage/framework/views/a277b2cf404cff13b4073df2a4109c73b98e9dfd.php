<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.table'); ?>
    <?php $__env->slot('create', route('members.create')); ?>
    <?php $__env->slot('titulo', 'Cargo'); ?>
    <?php $__env->slot('head'); ?>
        <th>Nome</th>
        <th>E-mail</th>
        <th></th>
    <?php $__env->endSlot(); ?>
    <?php $__env->slot('body'); ?>
        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($member->name); ?></td>
                <td><?php echo e($member->email); ?></td>
                <td class="options">
                    <a href="<?php echo e(route('members.edit', $member->id)); ?>" class="btn btn-primary"><i class="fas fa-pen"></i></a>
                    <form class="form-delete" action="<?php echo e(route('members.destroy', $member->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/components/dataTable.js')); ?>"></script>
    <script src="<?php echo e(asset('js/components/sweetAlert.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josueodh/Área de Trabalho/modelagem/resources/views/members/index.blade.php ENDPATH**/ ?>