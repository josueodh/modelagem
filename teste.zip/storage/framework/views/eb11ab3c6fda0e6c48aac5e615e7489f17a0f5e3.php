<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-book"></i> Preço</b>
    <br>
    <?php echo e($project->price); ?>

</li>
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-book"></i> Cliente</b>
    <br>
    <?php echo e($project->client); ?>

</li>
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-book"></i> Categoria de projeto</b>
    <br>
    <?php echo e($project->category['name']); ?>

</li>
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-users"></i> Membros</b>
    <br>
    <?php $__currentLoopData = $project->user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($user->name); ?>

        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</li>
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-users"></i> Descrição do Projeto</b>
    <br>
    <?php echo e($project->description); ?>

</li><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/projects/list.blade.php ENDPATH**/ ?>