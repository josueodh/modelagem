<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.edit'); ?>
    <?php $__env->slot('title', 'Editar Cargo'); ?>
    <?php $__env->slot('url', route('roles.update', $role->id)); ?>
    <?php $__env->slot('form'); ?>
        <?php echo $__env->make('roles.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/roles/edit.blade.php ENDPATH**/ ?>