<?php $__env->startSection('content'); ?>

<?php $__env->startComponent('components.show'); ?>
    <?php $__env->slot('title', $warning->title); ?>
    <?php $__env->slot('list'); ?>
        <?php echo $__env->make('warnings.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->endSlot(); ?>
    <?php $__env->slot('delete',route('warnings.destroy',$warning->id)); ?>    
    <?php $__env->slot('edit',route('warnings.edit',$warning->id)); ?>    
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/components/sweetAlert.js')); ?>"></script>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/warnings/show.blade.php ENDPATH**/ ?>