<div class="row">
    <div class="form-group col-12">
        <label class="required" for="title">Titulo</label>
        <input type="text" class="form-control" required value="<?php echo e(old('title', $warning->title)); ?>" name="title" id="title">
    </div>
    <div class="form-group col-12">
        <label class="required">Mensagem</label>
        <textarea required class="form-control" id="mensagem" name="description" rows="5"><?php echo e($warning->description); ?></textarea>
    </div>
    <input type="hidden" name="user_id" value="1">
</div><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/warnings/form.blade.php ENDPATH**/ ?>