<?php $__env->startSection('content'); ?>


<?php $__env->startComponent('components.table'); ?>
    <?php $__env->slot('create', route('projects.create')); ?>
    <?php $__env->slot('titulo', 'Cargos'); ?>


    <?php $__env->slot('head'); ?>
        <th>Nome</th>
        <th>Preço</th>
        <th>Cliente</th>
        <th></th>
    <?php $__env->endSlot(); ?>
    <?php $__env->slot('body'); ?>
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($project->name); ?></td>
                <td><?php echo e($project->price); ?></td>
                <td><?php echo e($project->cliente); ?></td>
                <td class="options">
                    <a href="<?php echo e(route('projects.show', $project->id)); ?>" class="btn btn-secondary"><i class="fas fa-eye"></i></a>
                    <a href="<?php echo e(route('projects.edit', $project->id)); ?>" class="btn btn-primary"><i class="fas fa-pen"></i></a>
                    <form class="form-delete" action="<?php echo e(route('projects.destroy', $project->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/components/dataTable.js')); ?>"></script>
    <script src="<?php echo e(asset('js/components/sweetAlert.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/project/index.blade.php ENDPATH**/ ?>