<?php $__env->startSection('content'); ?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1>Perfil do membro</h1>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3">

                <!-- Profile Image -->
                <div class="card card-outline card-code">
                    <div class="card-body box-profile">
                        <div class="text-center">
                            <img class="profile-user-img img-fluid img-circle" src="<?php echo e(asset('img/user.jpg')); ?>"
                                alt="User profile picture">
                        </div>

                        <h3 class="profile-username text-center"><?php echo e($user->name); ?></h3>

                        <p class="text-muted text-center"><?php echo e($user->role['name']); ?></p>

                        <ul class="list-group list-group-unbordered mb-3">
                            <li class="list-group-item">
                                <b>Gestões na Code</b> <a class="float-right">2</a>
                            </li>
                            <li class="list-group-item">
                                <b>Nº de Projetos</b> <a class="float-right">0</a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->

                <!-- About Me Box -->
                <div class="card card-outline card-code">
                    <div class="card-header">
                        <h3 class="card-title">Sobre mim</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <strong><i class="fas fa-book mr-1"></i> E-mail</strong>

                        <p class="text-muted">
                            <?php echo e($user->email); ?>

                        </p>

                        <hr>

                        <strong><i class="far fa-file-alt mr-1"></i> Projetos</strong>
                        <?php $__currentLoopData = $user->project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="text-muted"><?php echo e($project->name); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
            <div class="col-md-9">
                <div class="card card-outline card-code">
                    <div class="card-header p-2">
                        <h3>Avisos</h3>
                    </div><!-- /.card-header -->
                    <div class="card-body">
                        <div class="tab-content">
                            <div class="active tab-pane" id="activity">
                                <!-- Post -->
                                <?php $__currentLoopData = $warnings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="post">
                                        <div class="row">
                                            <div class="user-block col-sm-6">
                                                <img class="img-circle img-bordered-sm" src="<?php echo e(asset('img/user.jpg')); ?>"
                                                    alt="Imagem do responsável pelo aviso">
                                                <span class="username">
                                                    <a href="#"><?php echo e($warning->title); ?></a>
                                                    <span href="#" class="float-right btn-tool"></span>
                                                </span>
                                                <span class="description"><?php echo e(date('d-m-y', strtotime($warning->created_at))); ?></span>
                                            </div>
                                            <div class="col-sm-6">
                                                <p><?php echo e($warning->description); ?></p>
                                            </div>
                                            <!-- /.user-block -->
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <!-- /.post -->
                            </div>
                            <!-- /.tab-content -->
                        </div><!-- /.card-body -->
                    </div>
                    <!-- /.nav-tabs-custom -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/josueodh/Área de Trabalho/Faculdade/modelagem/resources/views/users/show.blade.php ENDPATH**/ ?>