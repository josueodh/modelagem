
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-book"></i> Mensagem</b>
    <br>
    {{ $warning->description }}
</li>
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-user"></i> Autor: </b>
    {{ $warning->user['name'] }}
</li>
