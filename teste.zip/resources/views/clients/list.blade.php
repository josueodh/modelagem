<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-book"></i> Telefone</b>
    <br>
    {{ $client->cellphone }}
</li>
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-book"></i> E-mail</b>
    <br>
    {{ $client->email }}
</li>
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-book"></i> Status</b>
    <br>
    {{ $client->status }}
</li>
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-book"></i> Descrição</b>
    <br>
    {{ $client->description }}
</li>