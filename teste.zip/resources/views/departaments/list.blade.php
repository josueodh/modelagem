
<li class="list-group-item">
    <b class="title-list-show"><i class="fas fa-book"></i> Descrição</b>
    <br>
    {{ $departament->description }}
</li>